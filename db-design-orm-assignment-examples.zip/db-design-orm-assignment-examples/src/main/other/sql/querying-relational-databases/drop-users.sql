DROP TABLE IF EXISTS `db_design`.`users`;
