// TODO: declare URL where server listens for HTTP requests
const USERS_URL = ""

// TODO: retrieve all users from the server
export const findAllUsers = () => {}

// TODO: retrieve a single user by their ID
export const findUserById = (id) => {}

// TODO: delete a user by their ID
export const deleteUser = () => {}

// TODO: create a new user
export const createUser = (user) => {}

// TODO: update a user by their ID
export const updateUser = (id, user) => {}

// TODO: export all functions as the API to this service
export default {}
